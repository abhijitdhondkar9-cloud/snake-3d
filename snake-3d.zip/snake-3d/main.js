// main.js - 3D Snake: catch the ball, grow longer.
import * as THREE from "three";

// ---------- Step 2: scene, camera and board ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf6f7fb);
const camera = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 100);
camera.position.set(0, 14, 12);
camera.lookAt(0, 0, 0);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
document.body.append(renderer.domElement);
addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

scene.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.2));
const sun = new THREE.DirectionalLight(0xffffff, 1.5);
sun.position.set(5, 12, 6);
scene.add(sun);

// The board covers cells -6..5 on x and z; each cell is 1 unit.
const MIN = -6, MAX = 5;
const board = new THREE.Mesh(
  new THREE.BoxGeometry(12, 0.5, 12),
  new THREE.MeshStandardMaterial({ color: 0x3b5bdb })
);
board.position.set(-0.5, -0.25, -0.5);
const grid = new THREE.GridHelper(12, 12, 0xffffff, 0xffffff);
grid.position.set(-0.5, 0.01, -0.5);
grid.material.opacity = 0.3;
grid.material.transparent = true;
scene.add(board, grid);
const CENTER = new THREE.Vector3(-0.5, 0, -0.5);

// ---------- Step 3: snake and ball ----------
const cube = new THREE.BoxGeometry(0.9, 0.9, 0.9);
const skin = new THREE.MeshStandardMaterial({ color: 0x1b1f2a });
const headSkin = new THREE.MeshStandardMaterial({ color: 0x2b3245 });
let snake = [];
let parts = [];

const ball = new THREE.Mesh(
  new THREE.SphereGeometry(0.45, 24, 16),
  new THREE.MeshStandardMaterial({ color: 0xf08c00 })
);
scene.add(ball);
let food = { x: 3, z: 0 };

function syncMeshes() {
  while (parts.length < snake.length) {
    const m = new THREE.Mesh(cube, parts.length ? skin : headSkin);
    scene.add(m);
    parts.push(m);
  }
  while (parts.length > snake.length) scene.remove(parts.pop());
  snake.forEach((p, i) => parts[i].position.set(p.x, 0.45, p.z));
}

function placeFood() {
  const free = [];
  for (let x = MIN; x <= MAX; x++)
    for (let z = MIN; z <= MAX; z++)
      if (!snake.some((p) => p.x === x && p.z === z)) free.push({ x, z });
  food = free[Math.floor(Math.random() * free.length)];
}

// ---------- Step 6: play options ----------
const speeds = { Easy: 220, Normal: 150, Hard: 90 };
let speed = "Normal", walls = true, paused = false, running = false;

const menu = document.createElement("div");
menu.id = "menu";
menu.innerHTML = `
  <h1>3D Snake</h1>
  <p>Speed: <button>Easy</button><button class="on">Normal</button>
    <button>Hard</button></p>
  <p>Walls: <button id="walls" class="on">On</button></p>
  <button id="play">Play</button>`;
document.body.append(menu);

menu.onclick = (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (speeds[b.textContent]) {
    speed = b.textContent;
    menu.querySelectorAll("p:first-of-type button").forEach((x) => x.classList.toggle("on", x === b));
  }
  if (b.id === "walls") {
    walls = !walls;
    b.textContent = walls ? "On" : "Off";
    b.classList.toggle("on", walls);
  }
  if (b.id === "play") start();
};

// ---------- Step 4: move, catch, grow ----------
let dir = { x: 1, z: 0 }, nextDir = dir, score = 0, timer = null;
const scoreEl = document.getElementById("score");
const pausedEl = document.getElementById("paused");

const keys = {
  ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0],
  w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0],
};

addEventListener("keydown", (e) => {
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  const d = keys[k];
  if (d && running && !(d[0] === -dir.x && d[1] === -dir.z)) nextDir = { x: d[0], z: d[1] };
  if (k === " " && running) { paused = !paused; pausedEl.hidden = !paused; }
  if (k === "r") start();
  if (k === "c") nextView();
  if (k.startsWith("Arrow") || k === " ") e.preventDefault();
});

function start() {
  clearInterval(timer);
  snake = [{ x: -1, z: 0 }, { x: -2, z: 0 }, { x: -3, z: 0 }];
  dir = nextDir = { x: 1, z: 0 };
  score = 0;
  scoreEl.textContent = score;
  paused = false;
  pausedEl.hidden = true;
  running = true;
  menu.hidden = true;
  syncMeshes();
  placeFood();
  timer = setInterval(step, speeds[speed]);
}

function step() {
  if (paused) return;
  dir = nextDir;
  const h = { x: snake[0].x + dir.x, z: snake[0].z + dir.z };
  if (!walls) {
    if (h.x > MAX) h.x = MIN; if (h.x < MIN) h.x = MAX;
    if (h.z > MAX) h.z = MIN; if (h.z < MIN) h.z = MAX;
  }
  if (hits(h)) return gameOver();
  snake.unshift(h);
  if (h.x === food.x && h.z === food.z) {
    score++;
    scoreEl.textContent = score;
    placeFood();
  } else {
    snake.pop();
  }
  syncMeshes();
}

// ---------- Step 7: game over and restart ----------
function hits(h) {
  const out = h.x < MIN || h.x > MAX || h.z < MIN || h.z > MAX;
  // The tail moves away this step, so it doesn't count.
  const self = snake.slice(0, -1).some((p) => p.x === h.x && p.z === h.z);
  return (walls && out) || self;
}

function gameOver() {
  clearInterval(timer);
  running = false;
  menu.querySelector("h1").textContent = "Game over: " + score;
  menu.querySelector("#play").textContent = "Play again";
  menu.hidden = false;
}

// ---------- Step 5: camera views (press C) ----------
const views = [
  { pos: new THREE.Vector3(-0.5, 14, 11.5), name: "Angle" },
  { pos: new THREE.Vector3(-0.5, 20, -0.49), name: "Top" },
  { pos: null, name: "Follow" },
];
let view = 0;
const viewEl = document.getElementById("view");
function nextView() {
  view = (view + 1) % views.length;
  viewEl.textContent = "View: " + views[view].name;
}

const target = new THREE.Vector3();
const look = CENTER.clone();
function updateCamera() {
  const v = views[view];
  if (v.pos || !parts.length) {
    target.copy(v.pos || views[0].pos);
    look.lerp(CENTER, 0.1);
  } else {
    const h = parts[0].position;
    target.set(h.x - 4, 6, h.z + 5);
    look.lerp(h, 0.15);
  }
  camera.position.lerp(target, 0.08);
  camera.lookAt(look);
}

// ---------- The loop: draw every frame ----------
renderer.setAnimationLoop((ms) => {
  ball.position.set(food.x, 0.45 + Math.sin(ms / 250) * 0.08, food.z);
  ball.rotation.y = ms / 600;
  updateCamera();
  renderer.render(scene, camera);
});

syncMeshes();
